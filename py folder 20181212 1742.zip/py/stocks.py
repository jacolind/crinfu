"""
download SPY and their top 20 stocks. on stooq.
make a corr plot.
mean, vol, sharpe, sortino, IR.

especially needed if we make that plot in the pitch5min.
"""

## download SPY and top 20 stocks

# stooq
# https://github.com/datasets/s-and-p-500-companies/blob/master/data/constituents.csv


## make a corr plot

## calc risk adj returns, show in a table

## markovitz plot
